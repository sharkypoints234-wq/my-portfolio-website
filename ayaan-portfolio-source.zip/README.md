# Ayaan Hussain — Personal Portfolio

A modern, dark-navy portfolio website for a Software Engineering student, built with
TanStack Start (React 19), TypeScript, and Tailwind CSS v4.

Pages: Home, About, Skills, Projects, Certifications, Education, Contact.

## Run locally

You need Node.js 20+ (or Bun).

```sh
npm install
npm run dev
```

Then open the printed local URL (the dev server starts on port 8080 by default here).

Other commands:

- `npm run build` — production build
- `npm run test` — run the routing tests
- `npm run lint` / `npm run format` — lint and format

## Where the content lives

All editable personal data is in one file: `src/data/portfolio.ts` — profile, contact
links, photo, skills, projects, experience, education. Change the values there and the
whole site updates.

## Images

All images are included in `src/assets/` (profile photo, hero illustration, project
images, including the E-Store prototype screen). The two hosted assets have been
downloaded into the folder so the project runs standalone.

Note: `src/routeTree.gen.ts` (the generated route table) is not included in this
archive — it is created automatically the first time you run the dev server or build.
