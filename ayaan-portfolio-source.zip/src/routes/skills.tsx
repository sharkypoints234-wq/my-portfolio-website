import { createFileRoute } from '@tanstack/react-router';
import { portfolioHead } from '@/data/portfolio';
import { PageHeading, SkillsGrid } from '@/components/portfolio/portfolio-ui';
export const Route = createFileRoute('/skills')({ head: () => portfolioHead('Technical Skills', 'Languages, tools, and foundational concepts I’m exploring as a Software Engineering student. No proficiency or certification levels are claimed.'), component: Page });
function Page() { return <main className="min-h-[75vh]"><PageHeading eyebrow="MY TOOLKIT" title="A toolkit in progress" copy={'Languages, tools, and foundational concepts I’m exploring as a Software Engineering student. No proficiency or certification levels are claimed.'}/><section className="site-width section reveal"><SkillsGrid/></section></main>; }
