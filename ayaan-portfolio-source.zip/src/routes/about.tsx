import { createFileRoute } from '@tanstack/react-router';
import { portfolioHead } from '@/data/portfolio';
import { PageHeading, AboutContent } from '@/components/portfolio/portfolio-ui';
export const Route = createFileRoute('/about')({ head: () => portfolioHead('About Me', 'A curious student, a growing developer, and a firm believer that every new challenge is a chance to learn.'), component: Page });
function Page() { return <main className="min-h-[75vh]"><PageHeading eyebrow="ABOUT ME" title="The person behind the code" copy={'A curious student, a growing developer, and a firm believer that every new challenge is a chance to learn.'}/><section className="site-width section reveal"><AboutContent/></section></main>; }
