import { createFileRoute } from '@tanstack/react-router';
import { portfolioHead } from '@/data/portfolio';
import { PageHeading, ProjectsGrid } from '@/components/portfolio/portfolio-ui';
export const Route = createFileRoute('/projects')({ head: () => portfolioHead('Projects & Explorations', 'Real work so far — the E-Store CCP project and this very website — alongside clearly labelled project ideas, not completed-work claims.'), component: Page });
function Page() { return <main className="min-h-[75vh]"><PageHeading eyebrow="IDEAS INTO CODE" title="From an idea to a possibility" copy={'Real work so far — the E-Store CCP project and this very website — alongside clearly labelled project ideas, not completed-work claims.'}/><section className="site-width section reveal"><ProjectsGrid/></section></main>; }
