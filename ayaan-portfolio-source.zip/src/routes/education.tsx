import { createFileRoute } from '@tanstack/react-router';
import { portfolioHead } from '@/data/portfolio';
import { PageHeading, EducationContent } from '@/components/portfolio/portfolio-ui';
export const Route = createFileRoute('/education')({ head: () => portfolioHead('Education', 'Software Engineering at Indus University — currently in the fourth semester.'), component: Page });
function Page() { return <main className="min-h-[75vh]"><PageHeading eyebrow="MY ACADEMIC JOURNEY" title="Building a strong foundation" copy={'Studying Software Engineering at Indus University, currently in the fourth semester.'}/><section className="site-width section reveal"><EducationContent/></section></main>; }
