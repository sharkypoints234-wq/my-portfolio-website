import { createFileRoute } from '@tanstack/react-router';
import { portfolioHead } from '@/data/portfolio';
import { PageHeading, ContactContent } from '@/components/portfolio/portfolio-ui';
export const Route = createFileRoute('/contact')({ head: () => portfolioHead('Contact Me', 'Projects, opportunities, or a good conversation about technology — I’d love to hear from you.'), component: Page });
function Page() { return <main className="min-h-[75vh]"><PageHeading eyebrow="GET IN TOUCH" title="Let’s start a conversation" copy={'Projects, opportunities, or a good conversation about technology — I’d love to hear from you.'}/><section className="site-width section reveal"><ContactContent/></section></main>; }
