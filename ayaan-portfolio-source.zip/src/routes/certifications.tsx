import { createFileRoute } from '@tanstack/react-router';
import { portfolioHead } from '@/data/portfolio';
import { PageHeading, CertificationsContent } from '@/components/portfolio/portfolio-ui';
export const Route = createFileRoute('/certifications')({ head: () => portfolioHead('Certifications', 'A space for future AI and programming course certificates. These placeholders do not represent earned qualifications.'), component: Page });
function Page() { return <main className="min-h-[75vh]"><PageHeading eyebrow="CONTINUOUS LEARNING" title="Learning beyond the classroom" copy={'A space for future AI and programming course certificates. These placeholders do not represent earned qualifications.'}/><section className="site-width section reveal"><CertificationsContent/></section></main>; }
