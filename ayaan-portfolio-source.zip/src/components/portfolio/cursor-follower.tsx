import { useEffect, useRef } from 'react';
import { Code2 } from 'lucide-react';

export function CursorFollower() {
  const follower = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = follower.current;
    if (!element) return;
    const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
    const mouse = window.matchMedia('(hover: hover) and (pointer: fine)');
    let frame = 0;
    let visible = false;
    let x = 0;
    let y = 0;
    let targetX = 0;
    let targetY = 0;

    function hide() {
      visible = false;
      element?.classList.remove('is-visible');
      window.cancelAnimationFrame(frame);
      frame = 0;
    }
    function animate() {
      if (!element || !visible) return;
      x += (targetX - x) * 0.3;
      y += (targetY - y) * 0.3;
      element.style.transform = `translate3d(${x}px, ${y}px, 0)`;
      if (Math.abs(targetX - x) + Math.abs(targetY - y) > 0.1) {
        frame = window.requestAnimationFrame(animate);
      } else {
        frame = 0;
      }
    }
    function move(event: PointerEvent) {
      if (preference.matches || !mouse.matches || event.pointerType !== 'mouse') return;
      targetX = event.clientX + 8;
      targetY = event.clientY + 8;
      if (!visible) {
        x = targetX;
        y = targetY;
        visible = true;
        element?.classList.add('is-visible');
      }
      if (!frame) frame = window.requestAnimationFrame(animate);
    }
    function leave(event: PointerEvent) {
      if (!event.relatedTarget) hide();
    }
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerout', leave);
    window.addEventListener('blur', hide);
    preference.addEventListener('change', hide);
    mouse.addEventListener('change', hide);
    return () => {
      hide();
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerout', leave);
      window.removeEventListener('blur', hide);
      preference.removeEventListener('change', hide);
      mouse.removeEventListener('change', hide);
    };
  }, []);

  return <div ref={follower} className="cursor-follower" aria-hidden="true"><Code2 className="size-5"/></div>;
}