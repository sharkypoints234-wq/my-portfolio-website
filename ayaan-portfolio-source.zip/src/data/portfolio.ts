import databaseImage from '@/assets/project-database.jpg';
import thisSiteImage from '@/assets/project-this-site.jpg';
import aiImage from '@/assets/project-ai.jpg';
import estoreImage from '@/assets/project-estore.jpg';
import profilePhoto from '@/assets/profile-photo.png';

// All social links are live.
export const profile = {
 name: 'Ayaan Hussain', initials: 'AH', role: 'Software Engineering Student',
 email: 'sharkypoints234@gmail.com', github: 'https://github.com/sharkypoints234-wq', linkedin: 'https://www.linkedin.com/in/ayaan-hussain-b7026b336/', fiverr: 'https://www.fiverr.com/sellers/ayaanhussain6', photo: profilePhoto,
 university: 'Indus University', degree: 'Software Engineering', semester: '4th semester',
};
export const experience = [
 { role: 'Call Center Representative', period: '2022', employer: '', copy: 'Real-world work experience in customer communication — answering inquiries, listening carefully, and helping people solve their problems.' },
];
export const skills = [
 { name: 'HTML', symbol: '</>', category: 'Web structure', color: 'text-rose' },
 { name: 'CSS', symbol: '#', category: 'Design & styling', color: 'text-eyebrow' },
 { name: 'JavaScript', symbol: 'JS', category: 'Web interactivity', color: 'text-amber' },
 { name: 'Python', symbol: 'Py', category: 'Programming & AI', color: 'text-mint' },
 { name: 'C++', symbol: 'C++', category: 'Problem solving', color: 'text-eyebrow' },
 { name: 'Databases', symbol: 'DB', category: 'Data management', color: 'text-mint' },
 { name: 'Software Engineering', symbol: '{ }', category: 'Concepts & fundamentals', color: 'text-rose' },
];
export const projects = [
 { title: 'E-Store Management System', eyebrow: 'Coursework project · Indus University', category: 'SOFTWARE ENGINEERING · CCP', image: estoreImage, concept: false, tags: ['SRS Analysis', 'SDLC', 'Prototyping', 'QA & Testing'], description: 'My CCP coursework: analyzing and prototyping the Marvel Electronics E-Store across three modules — customer, product, and order management.', details: 'Real coursework at Indus University (BS(SE) — Software Engineering). Working from the given SRS, the project applies all four SDLC phases — analysis, design, coding, and testing — and produced 8 low-fidelity prototype screens across the three modules, verified by 15 test cases (5 per module). It also covers QA vs QC, AI4SE (using AI tools to build software faster), and SE4AI (engineering a responsible AI feature such as a recommendation engine). Shown above: the Product Catalog prototype screen.' },
 { title: 'Database Management System', eyebrow: 'Project concept · Illustrative visual', concept: true, category: 'DATABASE DEVELOPMENT', image: databaseImage, tags: ['SQL', 'Python', 'Database Design'], description: 'A proposed system for organizing records, managing queries, and making everyday data easier to work with.', details: 'Project concept: design a relational schema, implement create/read/update/delete operations, and explore useful reporting queries. Replace this example with your real project, screenshots, and repository.' },
 { title: 'Personal Portfolio Website', eyebrow: 'Live project · This website', category: 'WEB DEVELOPMENT · THIS SITE', image: thisSiteImage, concept: false, tags: ['React', 'CSS', 'JavaScript', 'Responsive design'], description: 'The website you’re looking at right now — my own corner of the web, designed and built from scratch.', details: 'This very portfolio: a dark navy design with soft blue accents, seven linked pages, working navigation, project detail dialogs, a contact form, and small touches like the animated cursor follower. Fully responsive across phone, tablet, and laptop. Shown above: the real home page, not a mockup.' },
 { title: 'AI-Based Project', eyebrow: 'Project concept · Illustrative visual', concept: true, category: 'ARTIFICIAL INTELLIGENCE', image: aiImage, tags: ['Python', 'AI', 'Machine Learning'], description: 'An exploratory project idea focused on understanding how AI can solve practical, everyday problems.', details: 'Project concept: explore a simple classification or recommendation problem, prepare a dataset, and compare results. This is a placeholder, not a claim of completed work.' },
];
export function portfolioHead(title: string, description: string) {
 return { meta: [{ title: `${title} | Ayaan Hussain` }, { name: 'description', content: description }, { property: 'og:title', content: `${title} | Ayaan Hussain` }, { property: 'og:description', content: description }, { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' }] };
}
